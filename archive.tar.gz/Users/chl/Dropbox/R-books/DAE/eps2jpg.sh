#!/usr/bin/env sh
for f in *.eps
do
     dest=`echo ${f%.*}`
     echo "${f} to ${dest}.jpg"
     convert "${f}" "${dest}.jpg"
done
