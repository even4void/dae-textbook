#!/usr/bin/env python

# Time-stamp: <2009-11-28 21:39:54 chl>

# Make an image gallery of all files (jpg) found in a given
# directory. Actually, this merely a minimalist script that
# should evolve to produce well-formed HTML file.

import os, sys, glob
import Image

WD = "gallery"
ext = "_thumb.jpg"
filelist = os.listdir(WD)
size = 128,128  

# create thumbnails
for infile in filelist:
    print "Processing file: ", infile
    outfile = os.path.splitext(infile)[0] + ext
    if infile != outfile:
        try:
            im = Image.open(os.path.join(WD,infile))
            im.thumbnail(size)
            im.save(os.path.join(WD,outfile), "JPEG")
            print "done"
        except IOError:
            print "cannot create thumbnail for", infile

# generate HTML page
f = open('index.html', 'w')

pattern = '*' + ext
all_files = glob.glob(os.path.join(WD,pattern))
for infile in all_files:
    row = '<img src=%s width=%d height=%d />' % (infile, size[0], size[1])
    f.write(row + '\n')

f.close()
