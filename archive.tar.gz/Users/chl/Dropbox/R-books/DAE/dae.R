######################################################################
# Design and Analysis of Experiments -- Douglas Montgomery
# dae.tex
# R version 2.10.0 (2009-10-26)
# (c) Christophe Lalanne, 2009
######################################################################


######################################################################
## Sampling distributions
######################################################################
  x <- rnorm(10)

  set.seed(891)

  # Tension Bond Strength data (Tab. 2-1, p. 24)
  y1 <- c(16.85,16.40,17.21,16.35,16.52,17.04,16.96,17.15,16.59,16.57)
  y2 <- c(16.62,16.75,17.37,17.12,16.98,16.87,17.34,17.02,17.08,17.27)
  y <- data.frame(Modified=y1,Unmodified=y2) 
  y.means <- as.numeric(apply(y,2,mean))
  opar <- par(mfrow=c(2,1),mar=c(5,7,4,2),las=1)
  stripchart(y,xlab=expression("Strength (kgf/cm^2)"),pch=19)
  arrows(y.means,rep(1.5,2),y.means,c(1.1,1.9),length=.1)
  text(y.means,c(1.2,1.8),round(y.means,2),pos=4,cex=.8)
  # Random deviates (instead of data from metal recovery used in the book)
  rd <- rnorm(200,mean=70,sd=5)
  hist(rd,xlab="quantile",ylab="Relative frequency",
       main="Random Normal Deviates\n N(70,5)")
  par(opar)

  boxplot(y,ylab="Strength (kgf/cm^2)",las=1)

  x <- seq(-3.5,3.5,by=0.01)
  y <- dnorm(x)
  plot(x,y,xlab="",ylab="",type="l",axes=F,lwd=2)
  axis(side=1,cex.axis=.8); axis(2,pos=0,las=1,cex.axis=.8)
  mtext(expression(mu),side=1,line=2,at=0)
  mtext(expression(paste(frac(1, sigma*sqrt(2*pi)), " ",
                         plain(e)^{frac(-(x-mu)^2,
                         2*sigma^2)})),side=3,line=0)
  # highlight a specific area (drawing is from left to right, 
  # then from right to left)
  polygon(c(x[471:591],rev(x[471:591])),c(rep(0,121),rev(y[471:591])),
          col="lightgray",border=NA)


######################################################################
## The two-sample $t$-test
######################################################################
  t.test(y1,y2,var.equal=TRUE)

	Two Sample t-test

data:  y1 and y2 
t = -2.1869, df = 18, p-value = 0.0422
alternative hypothesis: true difference in means is not equal to 0 
95 percent confidence interval:
 -0.54507339 -0.01092661 
sample estimates:
mean of x mean of y 
   16.764    17.042 

  as.numeric(diff(apply(y,2,mean)))

  t.test(y1,y2)


######################################################################
## Application to paired samples
######################################################################
  tmp <- scan("hardness.txt",sep=",")
  hardness <- data.frame(y=tmp,tip=gl(2,10))
  t.test(y~tip,data=hardness,paired=TRUE)

  with(hardness, plot(y[tip==1],y[tip==2],xlab="Tip 1",ylab="Tip 2"))
  abline(0,1)
  with(hardness, plot(y[tip==1]+y[tip==2],y[tip==1]-y[tip==2],
                      xlab="Tip 1 + Tip 2",ylab="Tip 1 - Tip 2",ylim=c(-3,3)))
  abline(h=0)

  t.test(y~tip,data=hardness,var.equal=TRUE)


######################################################################
## Non-parametric alternative
######################################################################
  wilcox.test(y1,y2)
  wilcox.test(y~tip,data=hardness,paired=TRUE)


######################################################################
## Analysis of the fixed effects model
######################################################################
  etch.rate <- read.table("etchrate.txt",header=T)
  grp.means <- with(etch.rate, tapply(rate,RF,mean))
  with(etch.rate, stripchart(rate~RF,vert=T,method="overplot",pch=1))
  stripchart(as.numeric(grp.means)~as.numeric(names(grp.means)),pch="x",
             cex=1.5,vert=T,add=T)
  title(main="Etch Rate data",ylab=expression(paste("Observed Etch Rate (",
        ring(A),"/min)")),xlab="RF Power (W)")
  legend("bottomright","Group Means",pch="x",bty="n")


######################################################################
## Estimating Model parameters
######################################################################
  # first, we convert each variable to factor
  etch.rate$RF <- as.factor(etch.rate$RF)
  etch.rate$run <- as.factor(etch.rate$run)
  # next, we run the model
  etch.rate.aov <- aov(rate~RF,etch.rate)
  summary(etch.rate.aov)

  # overall mean
  (erate.mean <- mean(etch.rate$rate))
  # treatment effects
  with(etch.rate, tapply(rate,RF,function(x) mean(x)-erate.mean))

  model.tables(etch.rate.aov)

  MSe <- summary(etch.rate.aov)[[1]][2,3]
  SD.pool <- sqrt(MSe/5)
  t.crit <- c(-1,1)*qt(.975,16)

  with(etch.rate, t.test(rate[RF==160],rate[RF==180],var.equal=TRUE))

  mean(tapply(etch.rate$rate,etch.rate$RF,var))/5

  mean(c(var(etch.rate$rate[etch.rate$RF==160]),
         var(etch.rate$rate[etch.rate$RF==180])))

  > confint(etch.rate.aov)
                  2.5 %    97.5 %
  (Intercept) 533.88153 568.51847
  RF180        11.70798  60.69202
  RF200        49.70798  98.69202
  RF220       131.30798 180.29202

  as.numeric(grp.means[4]-grp.means[1])+c(-1,1)*qt(.975,16)*sqrt(2*MSe/5)


######################################################################
## Model checking
######################################################################
  opar <- par(mfrow=c(2,2),cex=.8)
  plot(etch.rate.aov)
  par(opar)

  require(car)
  durbin.watson(etch.rate.aov)

  bartlett.test(rate~RF,data=etch.rate)

  levene.test(etch.rate.aov)

  shapiro.test(etch.rate$rate[etch.rate$RF==160])


######################################################################
## Comparison among treatment means
######################################################################
  pairwise.t.test(etch.rate$rate,etch.rate$RF,p.adjust.method="bonferroni") 
  pairwise.t.test(etch.rate$rate,etch.rate$RF,p.adjust.method="hochberg")

  TukeyHSD(etch.rate.aov)
  plot(TukeyHSD(etch.rate.aov),las=1)


######################################################################
## Power and Sample size
######################################################################
  grp.means <- c(575,600,650,675)
  power.anova.test(groups=4,between.var=var(grp.means),within.var=25^2,
                   sig.level=.01,power=.90)

     Balanced one-way analysis of variance power calculation 

         groups = 4
              n = 3.520243
    between.var = 2083.333
     within.var = 625
      sig.level = 0.01
          power = 0.9

  NOTE: n is number in each group 

  sd <- seq(20,80,by=2)
  nn <- seq(4,20,by=2)
  beta <- matrix(NA,nr=length(sd),nc=length(nn))
  for (i in 1:length(sd)) 
    beta[i,] <- power.anova.test(groups=4,n=nn,between.var=var(grp.means),
                                 within.var=sd[i]^2,sig.level=.01)$power
  colnames(beta) <- nn; rownames(beta) <- sd
  opar <- par(las=1,cex=.8)
  matplot(sd,beta,type="l",xlab=expression(sigma),ylab=expression(1-beta),col=1,
          lty=1)
  grid()
  text(rep(80,10),beta[length(sd),],as.character(nn),pos=3)
  title("Operating Characteristic Curve\n for a=4 treatment means")
  par(opar)


######################################################################
## Non-parametric methods in ANOVA
######################################################################
  kruskal.test(rate~RF,data=etch.rate)

  library(npmc)
  # we need to reformat the data.frame with var/class names
  etch.rate2 <- etch.rate
  names(etch.rate2) <- c("class","run","var")
  summary(npmc(etch.rate2),type="BF")

  oneway.test(rate~RF,etch.rate)


######################################################################
## Randomized Complete Block Design
######################################################################
  x <- scan("vascgraft.txt")
  PSI.labels <- c(8500,8700,8900,9100)
  vasc.graft <- data.frame(PSI=gl(4,6,24),block=gl(6,1,24),x)
  vasc.graft.aov <- aov(x~block+PSI,vasc.graft)

  opar <- par(mfrow=c(2,2),cex=.8)
  plot(vasc.graft.aov)
  par(opar)

  # we delete the 10th observation
  x2 <- x
  x2[10] <- NA
  vasc.graft2 <- data.frame(PSI=gl(4,6,24),block=gl(6,1,24),x2)


######################################################################
## Latin Square Design
######################################################################
  rocket <- read.table("rocket.txt",header=T)

  plot(y~op+batch+treat,rocket)

  rocket.lm <- lm(y~factor(op)+factor(batch)+treat,rocket)
  anova(rocket.lm)


######################################################################
## Balanced Incomplete Block Designs
######################################################################
  tab.4.21 <- matrix(c(73,NA,73,75,74,75,75,NA,NA,67,68,72,71,72,NA,75),nc=4)
  tab.4.21.df <- data.frame(rep=as.vector(tab.4.21),
                            treat=factor(rep(1:4,4)),
                            block=factor(rep(1:4,each=4)))
  summary(aov(rep~treat+block+Error(block),tab.4.21.df))

  anova(lm(rep~block+treat,tab.4.21.df))

Error: block
      Df Sum Sq Mean Sq
treat  3 55.000  18.333

Error: Within
          Df  Sum Sq Mean Sq F value  Pr(>F)  
treat      3 22.7500  7.5833  11.667 0.01074 *
Residuals  5  3.2500  0.6500                  
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 

Error: treat
      Df  Sum Sq Mean Sq
treat  3 11.6667  3.8889

Error: Within
          Df Sum Sq Mean Sq F value    Pr(>F)    
block      3 66.083  22.028  33.889 0.0009528 ***
Residuals  5  3.250   0.650                      
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 

  require(agricolae)
  BIB.test(tab.4.21.df$treat,tab.4.21.df$treat,tab.4.21.df$rep,
           method="tukey",group=FALSE)

  tab.4.21.lm <- lm(rep~block+treat,tab.4.21.df)
  treat.coef <- tab.4.21.lm$coef[5:7]
  # effect for catalyst 4 (baseline) is missing, so we add it
  treat.coef <- c(0,treat.coef)
  pairwise.diff <- outer(treat.coef,treat.coef,"-")

  crit.val <- qtukey(0.95,4,5)

  ic.width <- crit.val*0.6982/sqrt(2)
  xx <- pairwise.diff[lower.tri(pairwise.diff)]
  plot(xx,1:6,xlab="Pairwise Difference
      (95% CI)",ylab="",xlim=c(-5,5),pch=19,cex=1.2,axes=F)
  axis(1,seq(-5,5))
  mtext(c("4-1","4-2","4-3","1-2","1-3","2-3"),side=2,at=1:6,line=2,las=2)
  segments(xx-ic.width,1:6,xx+ic.width,1:6,lwd=2)
  abline(v=0,lty=2,col="lightgray")

  tab.4.21.lm.crd <- lm(rep~treat,tab.4.21.df)
  (summary(tab.4.21.lm.crd)$sig/summary(tab.4.21.lm)$sig)^2

  require(lattice)
  xyplot(rep~treat|block,tab.4.21.df,
         aspect="xy",xlab="Catalyst",ylab="Response",
         panel=function(x,y) {
           panel.xyplot(x,y)
           panel.lmline(x,y)
         })

  require(lme4)
  print(tab.4.21.lm <- lmer(rep~treat+(1|block),tab.4.21.df),corr=F)

Linear mixed-effects model fit by REML 
Formula: rep ~ treat + (1 | block) 
   Data: tab.4.21.df 
   AIC   BIC logLik MLdeviance REMLdeviance
 44.22 46.64 -17.11      38.57        34.22
Random effects:
 Groups   Name        Variance Std.Dev.
 block    (Intercept) 8.00907  2.83003 
 Residual             0.65035  0.80644 
number of obs: 12, groups: block, 4

Fixed effects:
            Estimate Std. Error t value
(Intercept)  74.9704     1.4963   50.11
treat1       -3.5573     0.6973   -5.10
treat2       -3.3541     0.6973   -4.81
treat3       -2.9704     0.6973   -4.26

  print(tab.4.21.lm0 <- lmer(rep~-1+treat+(1|block),tab.4.21.df))

  coef(tab.4.21.lm)[[1]]$`(Intercept)`
  mean(coef(tab.4.21.lm)[[1]][,1])

  col <- c(1,1,0,1,1,1,0,0,0,1,0)
  perm <- function(x) { 
    s <- length(x)
    m <- matrix(nc=s,nr=s)
    y <- rep(x,2)
    m[,1] <- x
    for (i in 2:s) { m[,i] <- y[i:(s+i-1)] }
    m
  }
  col.perm <- perm(col)
  bib11 <- rbind(rep(0,11),col.perm)
  # check that the design is well balanced
  apply(bib11[-1,],1,sum)
  apply(bib11,2,sum)


######################################################################
## The two-factor factorial design
######################################################################
  battery <- read.table("battery.txt",header=TRUE)
  battery$Material <- as.factor(battery$Material)
  battery$Temperature <- as.factor(battery$Temperature)
  summary(battery)

  battery.aov <- aov(Life~Material*Temperature,data=battery)

  with(battery, interaction.plot(Temperature,Material,Life,type="b",pch=19,
                      fixed=T,xlab="Temperature (�F)",ylab="Average life"))

  plot.design(Life~Material*Temperature,data=battery)

  Tukey multiple comparisons of means
    95% family-wise confidence level

Fit: aov(formula = Life ~ . + .^2, data = battery)

$Material
        diff       lwr      upr     p adj
2-1 25.16667 -1.135677 51.46901 0.0627571
3-1 41.91667 15.614323 68.21901 0.0014162
3-2 16.75000 -9.552344 43.05234 0.2717815

  # we compute the three means at Temperature=70�F
  mm <- with(subset(battery, Temperature==70), 
             aggregate(Life,list(M=Material),mean))
  # next the studentized t quantile times the error type (based on pooled SD 
  # from ANOVA)
  val.crit <- qtukey(.95,3,27)*sqrt(unlist(summary(battery.aov))[["Mean Sq4"]]/4)
  # finally compare the observed difference of means with the critical value
  diff.mm <- c(d.3.1=mm$x[3]-mm$x[1],d.3.2=mm$x[3]-mm$x[2],d.2.1=mm$x[2]-mm$x[1])
  names(which(diff.mm > val.crit))

         15       70      125
1 2056.9167 556.9167 721.0000
2  656.2500 160.2500 371.0000
3  674.6667 508.2500 371.6667

            Df Sum Sq Mean Sq F value    Pr(>F)    
Material     2  10684    5342  5.9472  0.006515 ** 
Temperature  2  39119   19559 21.7759 1.239e-06 ***
Residuals   31  27845     898                      
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 

  mm2 <- with(battery, tapply(Life,list(Material,Temperature),mean))
  mm2 <- as.vector(mm2)
  plot(fitted(battery.aov2)[seq(1,36,by=4)],mm2-fitted(battery.aov2)[seq(1,36,by=4)],
       xlab="",ylab=expression(bar(y)[ij.]-hat(y)[ijk]),
       pch=19,axes=FALSE,ylim=c(-30,30))
  axis(1,at=seq(0,200,by=50),pos=0)
  text(155,4,expression(hat(y)[ijk]),pos=4)
  axis(2,at=seq(-30,30,by=10),las=1)

  yy <- order(fitted(battery.aov2)[seq(1,36,by=4)])
  xx.fit <- fitted(battery.aov2)[seq(1,36,by=4)]
  yy.fit <- mm2-fitted(battery.aov2)[seq(1,36,by=4)]
  lines(xx.fit[yy],predict(loess(yy.fit[yy]~xx.fit[yy])),col="lightgray",lwd=2)

  impurity <- read.table("impurity.txt",header=TRUE)
  impurity$Temperature <- as.factor(impurity$Temperature)
  impurity$Pressure <- as.factor(impurity$Pressure)

                     Df Sum Sq Mean Sq
Temperature           2 23.333  11.667
Pressure              4 11.600   2.900
Temperature:Pressure  8  2.000   0.250

  library(alr3)
  residual.plots(lm(N~Temperature+Pressure,impurity))


######################################################################
## The model described in the preceding section can be generalize...
######################################################################
  bottling <- read.table("bottling.txt",header=TRUE,
                         colClasses=c("numeric",rep("factor",3)))
  summary(bottling)

  opar <- par(mfrow=c(2,2),cex=.8)
  boxplot(Deviation~.,data=bottling,las=2,cex.axis=.8,ylab="Deviation")
  abline(h=0,lty=2)
  par(las=1)
  mm <- with(bottling, tapply(Deviation,Carbonation,mean))
  ss <- with(bottling, tapply(Deviation,Carbonation,sd))
  bp <- barplot(mm,xlab="Carbonation",ylab="Deviation",ylim=c(-2,9))
  arrows(bp,mm-ss/sqrt(4),bp,mm+ss/sqrt(4),code=3,angle=90,length=.1)
  with(bottling, interaction.plot(Carbonation,Pressure,Deviation,type="b"))
  with(bottling, interaction.plot(Carbonation,Speed,Deviation,type="b"))
  par(opar)

  summary(bottling.aov <- aov(Deviation~.^3,bottling))

  bottling.aov2 <- aov(Deviation~.,bottling)
  anova(bottling.aov2,bottling.aov)

  battery$Temperature.num <- as.numeric(as.character(battery$Temperature))
  battery.aov3 <- aov(Life~Material+Temperature.num+I(Temperature.num^2)
                      +Material:Temperature.num+Material:I(Temperature.num^2),
                      data=battery)
  summary(battery.aov3)

  new <- data.frame(Temperature.num=rep(seq(15,125,by=5),3),Material=gl(3,23))
  new$fit <- predict(battery.aov3,new)
  opar <- par(las=1)
  # we first plot the fitted values
  with(new, interaction.plot(Temperature.num,Material,fit,legend=FALSE,
                             xlab="Temperature",ylab="Life",ylim=c(20,190)))
  txt.leg <- paste("Material type",1:3)
  text(5:7,new$fit[new$Temperature.num==c(45,55,65)]-c(3,3,-20),txt.leg,pos=1)
  # next the observed values
  points(rep(c(1,15,23),each=12),battery$Life,pch=19)
  par(opar)

  tool <- read.table("toollife.txt",header=TRUE)
  tool.lm <- lm(Life~Angle*Speed+I(Angle^2)*I(Speed^2)+Angle:I(Speed^2)
                +I(Angle^2):Speed,tool) 
  tmp.angle <- seq(15,25,by=.1)
  tmp.speed <- seq(125,175,by=.5)
  tmp <- list(Angle=tmp.angle,Speed=tmp.speed)
  new <- expand.grid(tmp)
  new$fit <- c(predict(tool.lm,new))

Coefficients:
                        Estimate Std. Error t value Pr(>|t|)  
(Intercept)           -1.068e+03  7.022e+02  -1.521   0.1626  
Angle                  1.363e+02  7.261e+01   1.877   0.0932 .
Speed                  1.448e+01  9.503e+00   1.524   0.1619  
I(Angle^2)            -4.080e+00  1.810e+00  -2.254   0.0507 .
I(Speed^2)            -4.960e-02  3.164e-02  -1.568   0.1514  
Angle:Speed           -1.864e+00  9.827e-01  -1.897   0.0903 .
I(Angle^2):I(Speed^2) -1.920e-04  8.158e-05  -2.353   0.0431 *
Angle:I(Speed^2)       6.400e-03  3.272e-03   1.956   0.0822 .
Speed:I(Angle^2)       5.600e-02  2.450e-02   2.285   0.0481 *

  require(lattice)
  contourplot(fit~Angle*Speed,data=new,cuts=8,region=T,col.regions=gray(7:16/16))


######################################################################
## Blocking in a factorial design
######################################################################
  intensity <- read.table("intensity.txt",header=TRUE,
                          colClasses=c("numeric",rep("factor",3)))
  require(lattice)
  xyplot(Intensity~Ground|Operator,data=intensity,groups=Filter,
         panel=function(x,y,...){
           subs <- list(...)$subscripts
           panel.xyplot(x,y,pch=c(1,19),...)
           panel.superpose(x,y,panel.groups="panel.lmline",lty=c(1,2),...) 
         },key=list(text=list(lab=as.character(1:2)),lines=list(lty=1:2,col=1),
         corner=c(1,.95),title="Filter Type",cex.title=.8),col=1)

  intensity.aov <- aov(Intensity~Ground*Filter+Error(Operator),intensity)
  summary(intensity.aov)

Call:
aov(formula = Intensity ~ Ground * Filter + Error(Operator), 
    data = intensity)

Grand Mean: 94.91667 

Stratum 1: Operator

Terms:
                Residuals
Sum of Squares   402.1667
Deg. of Freedom         3

Residual standard error: 11.57824 

(...)


######################################################################
## The $2^2$ design
######################################################################
  yield <- read.table("yield.txt",header=T)
  attach(yield)
  rm(yield)
  yield.sums <- aggregate(yield,list(reactant=reactant,catalyst=catalyst),sum)

  reactant catalyst   x
1     high     high  90
2      low     high  60
3     high      low 100
4      low      low  80

  summary(aov(yield~reactant*catalyst))

  reactant.num <- reactant
  levels(reactant.num) <- c(25,15)
  reactant.num <- as.numeric(as.character(reactant.num))
  catalyst.num <- catalyst
  levels(catalyst.num) <- c(2,1)
  catalyst.num <- as.numeric(as.character(catalyst.num))
  yield.lm <- lm(yield~reactant.num+catalyst.num)
  yield.lm  ## gives the coefficients of the LM

  s3d <- scatterplot3d(reactant.num,catalyst.num,yield,type="n",
                       angle=135,scale.y=1,xlab="Reactant",ylab="Catalyst")
  s3d$plane3d(yield.lm,lty.box="solid",col="darkgray")
  tmp <- list(reactant.num=seq(15,25,by=.5),catalyst.num=seq(1,2,by=.1))
  new.data <- expand.grid(tmp)
  new.data$fit <- predict(yield.lm,new.data)
  contourplot(fit~reactant.num+catalyst.num,new.data,xlab="Reactant",
              ylab="Catalyst")


######################################################################
## The $2^3$ design
######################################################################
  plasma <- read.table("plasma.txt",header=TRUE)
  plasma

  Run  A  B  C   R1   R2
1   1 -1 -1 -1  550  604
2   2  1 -1 -1  669  650
3   3 -1  1 -1  633  601
4   4  1  1 -1  642  635
5   5 -1 -1  1 1037 1052
6   6  1 -1  1  749  868
7   7 -1  1  1 1075 1063
8   8  1  1  1  729  860

  plasma.df <- data.frame(etch=c(plasma$R1,plasma$R2),
                          rbind(plasma[,2:4],plasma[,2:4]))
  plasma.df[,2:4] <- lapply(plasma.df[,2:4],factor)

  plasma.df.aov <- aov(etch~A*B*C, data=plasma.df)
  summary(plasma.df.aov)

  plasma.num.df <- plasma.df
  levels(plasma.num.df$A) <- c(0.8,1.2)
  levels(plasma.num.df$C) <- c(275,325)
  plasma.num.df$A <- as.numeric(as.character(plasma.num.df$A))
  plasma.num.df$C <- as.numeric(as.character(plasma.num.df$C))
  plasma.num.df.lm <- lm(etch~A*C, plasma.num.df)

  tmp <- list(C=seq(275,325,by=1),A=seq(0.8,1.2,by=.1))
  new.data <- expand.grid(tmp)
  new.data$fit <- predict(plasma.num.df.lm, new.data)
  require(scatterplot3d)
  s3d <- scatterplot3d(plasma.num.df$A,plasma.num.df$C,
                       plasma.num.df$etch,type="n",
                       angle=135,scale.y=1,xlab="Gap",ylab="Power")
  s3d$plane3d(plasma.num.df.lm,lty.box="solid",col="darkgray")


  strength <- read.table("strength.txt",header=TRUE)
  strength$Looms <- factor(strength$Looms)
  strength$Obs <- factor(strength$Obs)
  library(nlme)
  strength.lmm <- lme(y~as.factor(Looms),data=strength,random=~1)

