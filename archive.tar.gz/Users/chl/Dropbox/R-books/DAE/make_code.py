#!/usr/bin/env python

# Extracts all the R code from tex book and put it into a separate
# R file (hence, mimicking the Sweave process).

# Time-stamp: <2009-11-03 21:56:25 chl>

import os, sys

if len(sys.argv) < 2:
    sys.exit("Extract R code from a tex file\nUsage:\n  make_code.py [filename.tex]")

cmd = 'R --version'
res = os.popen(cmd).read()
    
infile = sys.argv[1]
outfile = infile.replace('.tex','.R')

c = "#"
max_len = 70

F = open(infile,"r")
P = open(outfile,"w")
P.write(c*max_len+"\n")
P.write("# Design and Analysis of Experiments -- Douglas Montgomery\n")
P.write("# %s\n"%infile)
P.write("# %s\n"%res.split('\n')[0])
P.write("# (c) Christophe Lalanne, 2009\n")
P.write(c*max_len+"\n\n")

output = False
section = ""

for x in F.readlines():
    if x.find("section") != -1:
        i = x.find("{")
        j = x.find("}")
        section = x[i+1:j]
    if x.find("begin{verbatim}") != -1:
        output = True
        if section != "":
            if len(section) > max_len-7:
                section = section[0:max_len-8]+"..."
            P.write("\n"+c*max_len+"\n")
            P.write("## %s\n"%section)
            P.write(c*max_len+"\n")
            section = ""
        continue
    elif x.find("end{verbatim}") != -1:
        output = False
        P.write("\n")
        continue
    if output:
        P.write(x)
